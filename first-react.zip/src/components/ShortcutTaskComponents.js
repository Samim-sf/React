import React, {Component} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

class TaskShortCut extends Component {
    render(){
        return(
          <div>
              <h3></h3>
              <p></p>
              <button></button>
              <img src="" alt=""/>
          </div>
        );
    }

}